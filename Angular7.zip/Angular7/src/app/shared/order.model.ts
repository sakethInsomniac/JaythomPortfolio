export class Order {

  OrderID: string;
  OrderNo: string;
  CustomerID: number;
  PMethod: string;
  GTotal: number;
  DeletedOrderItemIDs: string;
}
