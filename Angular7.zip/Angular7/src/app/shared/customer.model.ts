export class Customer {
    CustomerID: number;
    Name: string ;
}
