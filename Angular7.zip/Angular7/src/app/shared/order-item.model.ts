export class OrderItem {

  OrderItemID: string;
  OrderID: number;
  ItemID: number;
  Quantity: number;
  ItemName: string;
  Price: number;
  Total: number;
  // PMethod: string;
  // GTotal: number;
}
